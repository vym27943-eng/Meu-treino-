# Rotina de Treino

Projeto Android inicial com interface local em WebView. A tela e os dados dos treinos funcionam offline; os registros ficam no armazenamento local do aplicativo.

## Gerar APK
O GitHub Actions gera um APK de teste automaticamente quando os arquivos são enviados para a branch `main`. Abra a aba Actions, entre na execução concluída e baixe o artefato `rotina-de-treino-apk`.

## Observação
Este APK é uma versão inicial de teste. Não contém ainda modelos anatômicos 3D nem vídeos demonstrativos; esses recursos serão adicionados depois, mantendo os arquivos de mídia no próprio aplicativo para uso offline.
